# 本程序及代码是在人工智能工具辅助下完成的。
# 辅助编程工具：Qwen3.8-Max（通义千问），阿里云（阿里巴巴）。
# 模型发布日期：2026-08-03。
# 本次辅助范围：程序编写辅助、注释整理、静态阅读与语法树一致性核对；未运行本程序。
# 历史开发工具记录见论文附录D；本次型号不替代未留存的历史型号。
"""Neutral public entry for the archived LBSS algorithm. No execution during packaging."""
from pathlib import Path
import argparse, subprocess, sys

def main():
    ap=argparse.ArgumentParser(description='LBSS multicore scheduling')
    ap.add_argument('--graph',type=Path,required=True)
    ap.add_argument('--cores',type=int,required=True)
    ap.add_argument('--scene',choices=['A','B','L2'],required=True)
    ap.add_argument('--budget',type=float,default=600)
    ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args()
    if not a.graph.is_file():ap.error('Original official input graph not found: '+str(a.graph))
    if a.cores<1 or a.budget<=0:ap.error('cores and budget must be positive')
    root=Path(__file__).resolve().parent/'engine'
    cmd=[sys.executable,'-B','-S',str(root/'round12_src/solve_round12.py'),str(a.graph.resolve()),'-n',str(a.cores),'--scene',a.scene,'--profile','full','--budget',str(a.budget),'--out',str(a.out.resolve())]
    return subprocess.call(cmd)
if __name__=='__main__':raise SystemExit(main())
