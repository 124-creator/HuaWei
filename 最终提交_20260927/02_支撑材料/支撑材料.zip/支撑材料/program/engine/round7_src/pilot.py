# 本程序及代码是在人工智能工具辅助下完成的。
# 本次工具：Qwen3.8-Max（通义千问），阿里云（阿里巴巴）。
# 模型发布日期：2026-08-03。
# 本次辅助范围：注释整理、静态阅读与语法树一致性核对；未运行本程序。
# 历史开发工具记录见论文附录D；本次型号不替代未留存的历史型号。
from task_frontier import *
from run_experiments import run_job,source_hash
import argparse,time,json

def main():
 ap=argparse.ArgumentParser();ap.add_argument('case');a=ap.parse_args();out=ROOT/'round7_results/pilot'/a.case;out.mkdir(parents=True,exist_ok=True)
 graph=ROOT/'official/data'/f'{a.case}.json';ix=GraphIndex(json.loads(graph.read_text()));start=time.perf_counter();rows=candidates(ix,5);manifest=[]
 for name,plan,meta in rows:
  pp=out/(name+'_plan.json');pp.write_text(json.dumps(plan,sort_keys=True));(out/(name+'_features.json')).write_text(json.dumps(meta,indent=2))
  r=run_job(dict(graph=str(graph),plan=str(pp),mode='A',cores=5,variant=name,output=str(out/(name+'_result.json'))),ROOT/'official',40,False,source_hash(ROOT/'official'),False)
  manifest.append(dict(name=name,meta=meta,status=r['status'],makespan=r.get('makespan')))
 (out/'summary.json').write_text(json.dumps(dict(case=a.case,wall=time.perf_counter()-start,rows=manifest),indent=2))
if __name__=='__main__':main()
