# 本程序及代码是在人工智能工具辅助下完成的。
# 本次工具：Qwen3.8-Max（通义千问），阿里云（阿里巴巴）。
# 模型发布日期：2026-08-03。
# 本次辅助范围：注释整理、静态阅读与语法树一致性核对；未运行本程序。
# 历史开发工具记录见论文附录D；本次型号不替代未留存的历史型号。
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
import subprocess,sys,json,time
root=Path(__file__).resolve().parents[1]
cases=['case_005','case_006','case_010','case_016','case_044','case_046','case_086']
def run(c):
 with (root/'round7_reports'/f'pilot_{c}.log').open('w') as log:
  p=subprocess.run([sys.executable,'-S',str(root/'round7_src/pilot.py'),c],stdout=log,stderr=subprocess.STDOUT)
 return c,p.returncode
with ThreadPoolExecutor(max_workers=3) as pool:
 for f in as_completed([pool.submit(run,c) for c in cases]):print(f.result(),flush=True)
