# 本程序及代码是在人工智能工具辅助下完成的。
# 本次工具：Qwen3.8-Max（通义千问），阿里云（阿里巴巴）。
# 模型发布日期：2026-08-03。
# 本次辅助范围：注释整理、静态阅读与语法树一致性核对；未运行本程序。
# 历史开发工具记录见论文附录D；本次型号不替代未留存的历史型号。
from pathlib import Path
import json,sys,subprocess,time
ROOT=Path(__file__).resolve().parents[1];rows=[]
# Chosen before running these checks; not used to retune prototype constants.
for case,n,scene,gap in [('case_001',4,'B',0.03),('case_003',2,'A',0),('case_007',3,'B',0),('case_008',5,'L2',0)]:
 out=ROOT/'results/cli_checks'/(case+'_'+scene+'_plan.json');out.parent.mkdir(parents=True,exist_ok=True)
 cmd=[sys.executable,str(ROOT/'src/solve_case_v2.py'),str(ROOT/'official/data'/(case+'.json')),'--official',str(ROOT/'official'),'-n',str(n),'--scene',scene,'--budget','90','--per-eval-timeout','20','--relative-gap-stop',str(gap),'-o',str(out)]
 start=time.perf_counter()
 try:
  r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=110)
  out.with_suffix('.console.txt').write_text(r.stdout);rows.append({'case':case,'cores':n,'scene':scene,'returncode':r.returncode,'wall_seconds':time.perf_counter()-start})
 except subprocess.TimeoutExpired as exc: rows.append({'case':case,'status':'cli_timeout','wall_seconds':time.perf_counter()-start})
 (ROOT/'reports/cli_checks.json').write_text(json.dumps(rows,indent=2));print(rows[-1],flush=True)
