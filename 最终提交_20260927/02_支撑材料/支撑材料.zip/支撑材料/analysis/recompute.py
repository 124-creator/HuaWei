# 本程序及代码是在人工智能工具辅助下完成的。
# 本次工具：ChatGPT，GPT-6 Astra Pro，OpenAI。
# Astra系列公告日期：2026-09-03（Pro未另列发布日期）。
# 本次辅助范围：注释整理、静态阅读与语法树一致性核对；未运行本程序。
# 历史开发工具记录见论文附录D；本次型号不替代未留存的历史型号。
"""Frozen-table statistics only. Does not import program/ or an evaluator."""
from pathlib import Path
from statistics import median
import csv, json, hashlib
root=Path(__file__).resolve().parents[1]
v=root/'results/verification.json';q=root/'results/tables/Q1_per_case.csv'
r=[x for x in json.loads(v.read_text(encoding='utf-8'))['checks'] if x['kind']=='selected']
assert len(r)==1400
result={'scope':'Frozen-table read-only recomputation; selected configurations, not runtime gate frequency','scenes':{}}
for scene in ('A','B','L2'):
    z=[x for x in r if x['scene']==scene]
    result['scenes'][scene]={'total':len(z),'certificates_le_3pct':sum(x['compute_gap_upper_bound']<=.03 for x in z),'five_core_median_gap':median(x['compute_gap_upper_bound'] for x in z if x['cores']==5)}
sums={}
with q.open(encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):sums[row['case']]=sums.get(row['case'],0)+float(row['wall_seconds'])
result['A_successful_wall_sum']={'median':median(sums.values()),'above_600':sum(x>600 for x in sums.values()),'per_case':sums,'excludes':'Unrecorded failed-attempt elapsed time; not concurrent batch duration'}
result['sources']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (v,q)}
print(json.dumps(result,ensure_ascii=False,indent=2))
